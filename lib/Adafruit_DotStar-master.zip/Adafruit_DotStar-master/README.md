# Adafruit DotStar [![Build Status](https://github.com/adafruit/Adafruit_DotStar/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_DotStar/actions)

Arduino library for controlling two-wire-based LED pixels and strips such as Adafruit DotStar LEDs and other APA102-compatible devices.
